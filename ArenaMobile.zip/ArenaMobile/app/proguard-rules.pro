# WebView JavaScript interfaces are deliberately avoided. Add rules only for audited SDKs.
