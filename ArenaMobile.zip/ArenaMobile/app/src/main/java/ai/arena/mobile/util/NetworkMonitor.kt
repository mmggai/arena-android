package ai.arena.mobile.util
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NetworkMonitor(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val _online = MutableStateFlow(isOnline())
    val online: StateFlow<Boolean> = _online.asStateFlow()
    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: android.net.Network) { _online.value = true }
        override fun onLost(network: android.net.Network) { _online.value = isOnline() }
        override fun onCapabilitiesChanged(n: android.net.Network, c: NetworkCapabilities) { _online.value = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) }
    }
    init { cm.registerDefaultNetworkCallback(callback) }
    private fun isOnline() = cm.activeNetwork?.let { cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) } == true
}
