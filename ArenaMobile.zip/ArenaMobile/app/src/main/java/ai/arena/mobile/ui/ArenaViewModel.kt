package ai.arena.mobile.ui
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

@HiltViewModel class ArenaViewModel @Inject constructor() : ViewModel() {
    private val _loading = MutableStateFlow(true); val loading = _loading.asStateFlow()
    private val _pageTitle = MutableStateFlow("Arena"); val pageTitle = _pageTitle.asStateFlow()
    fun loaded() { _loading.value = false }
    fun loading() { _loading.value = true }
    fun title(value: String?) { if (!value.isNullOrBlank()) _pageTitle.value = value }
}
