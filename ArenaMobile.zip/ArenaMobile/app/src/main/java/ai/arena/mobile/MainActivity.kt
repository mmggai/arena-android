package ai.arena.mobile

import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import ai.arena.mobile.ui.ArenaViewModel
import ai.arena.mobile.util.NetworkMonitor
import ai.arena.mobile.web.ArenaWebView
import androidx.hilt.navigation.compose.hiltViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { ArenaApp(this) } }
    override fun onBackPressed() { (webView?.takeIf { it.canGoBack() })?.goBack() ?: super.onBackPressed() }
    private var webView: WebView? = null
    private fun setWebView(view: WebView) { webView = view }
    override fun onDestroy() { webView?.destroy(); super.onDestroy() }
    @Composable private fun ArenaApp(activity: MainActivity, vm: ArenaViewModel = hiltViewModel()) {
        val context = LocalContext.current
        val monitor = remember { NetworkMonitor(context.applicationContext) }
        val online by monitor.online.collectAsState()
        val loading by vm.loading.collectAsState()
        val title by vm.pageTitle.collectAsState()
        val dark = isSystemInDarkTheme()
        val scheme = if (android.os.Build.VERSION.SDK_INT >= 31) if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context) else if (dark) darkColorScheme() else lightColorScheme()
        val haptics = LocalHapticFeedback.current
        MaterialTheme(colorScheme = scheme) {
            val view = LocalView.current
            SideEffect { activity.window.statusBarColor = scheme.surface.toArgb(); WindowCompat.getInsetsController(activity.window, view).isAppearanceLightStatusBars = !dark }
            Scaffold(
                topBar = { CenterAlignedTopAppBar(title = { Text(if (title.length < 36) title else "Arena") }, navigationIcon = { IconButton(onClick = { if (webView?.canGoBack() == true) webView?.goBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }, actions = { IconButton(onClick = { haptics.performHapticFeedback(HapticFeedbackType.LongPress); vm.loading(); webView?.reload() }) { Icon(Icons.Default.Refresh, "Refresh") }; IconButton(onClick = { webView?.loadUrl("https://arena.ai/") }) { Icon(Icons.Default.MoreVert, "Arena home") } }) },
                contentWindowInsets = WindowInsets.safeDrawing
            ) { padding ->
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().padding(padding).pointerInput(Unit) {
                    var pull = 0f
                    detectVerticalDragGestures(onVerticalDrag = { _, amount ->
                        pull = (pull + amount).coerceAtLeast(0f)
                        if (pull > 180f && !loading) { haptics.performHapticFeedback(HapticFeedbackType.LongPress); vm.loading(); webView?.reload(); pull = 0f }
                    }, onDragEnd = { pull = 0f }, onDragCancel = { pull = 0f })
                }) {
                    ArenaWebView(Modifier.fillMaxSize(), activity, dark, vm::loading, vm::loaded, vm::title, activity::setWebView)
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    if (!online) Surface(tonalElevation = 4.dp, modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter)) { Text("You’re offline. Saved web content may still be available.", Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}
