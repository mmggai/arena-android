package ai.arena.mobile
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp class ArenaApplication : Application()
