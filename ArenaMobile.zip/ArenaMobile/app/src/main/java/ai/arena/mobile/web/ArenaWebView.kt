package ai.arena.mobile.web

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.File

private fun trusted(uri: Uri) = uri.scheme == "https" && (uri.host == "arena.ai" || uri.host?.endsWith(".arena.ai") == true)

@SuppressLint("SetJavaScriptEnabled")
@Composable fun ArenaWebView(
    modifier: Modifier, activity: Activity, dark: Boolean, onLoading: () -> Unit,
    onLoaded: () -> Unit, onTitle: (String?) -> Unit, onCreated: (WebView) -> Unit
) {
    var callback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    val contentPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data?.clipData?.let { clips -> Array(clips.itemCount) { clips.getItemAt(it).uri } }
            ?: result.data?.data?.let { arrayOf(it) } ?: captureUri?.let { if (result.resultCode == Activity.RESULT_OK) arrayOf(it) else null }
        callback?.onReceiveValue(data); callback = null; captureUri = null
    }
    val webRef = remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(dark) { webRef.value?.settings?.let { s -> if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) WebSettingsCompat.setForceDark(s, if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF) }; onDispose {} }
    AndroidView(modifier = modifier, factory = { context ->
        WebView(context).apply {
            webRef.value = this; onCreated(this)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
            settings.apply { javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true; loadsImagesAutomatically = true; mediaPlaybackRequiresUserGesture = true; allowFileAccess = false; allowContentAccess = true; javaScriptCanOpenWindowsAutomatically = false; setSupportMultipleWindows(false); userAgentString += " ArenaAndroid/1.0" }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) WebSettingsCompat.setForceDark(settings, if (dark) WebSettingsCompat.FORCE_DARK_ON else WebSettingsCompat.FORCE_DARK_OFF)
            CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    if (trusted(uri)) return false
                    return try { activity.startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: ActivityNotFoundException) { true }
                }
                override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) = onLoading()
                override fun onPageFinished(v: WebView, u: String?) { CookieManager.getInstance().flush(); onTitle(v.title); onLoaded() }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                    callback?.onReceiveValue(null); callback = cb
                    val takePhoto = Intent("android.media.action.IMAGE_CAPTURE").also { intent ->
                        val file = File(context.cacheDir, "camera/${System.currentTimeMillis()}.jpg").apply { parentFile?.mkdirs() }
                        captureUri = FileProvider.getUriForFile(context, "ai.arena.mobile.files", file)
                        intent.putExtra("output", captureUri); intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val choose = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, p.acceptTypes.filter { it.isNotBlank() }.toTypedArray()); putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.mode == FileChooserParams.MODE_OPEN_MULTIPLE) }
                    contentPicker.launch(Intent.createChooser(choose, "Upload to Arena").putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(takePhoto))); return true
                }
                override fun onCreateWindow(v: WebView, dialog: Boolean, userGesture: Boolean, resultMsg: Message): Boolean = false
                override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) { callback.invoke(origin, false, false) }
            }
            loadUrl("https://arena.ai/")
        }
    }, update = { webRef.value = it })
}
