plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
}

android { namespace = "ai.arena.mobile"; compileSdk = 35
    defaultConfig { applicationId = "ai.arena.mobile"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0.0" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(libs.androidx.core.ktx); implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.activity.compose); implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui); implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons); implementation(libs.androidx.lifecycle.viewmodel)
    implementation(libs.androidx.navigation); implementation(libs.androidx.hilt.navigation)
    implementation(libs.androidx.webkit); implementation(libs.hilt.android); ksp(libs.hilt.compiler)
    debugImplementation(libs.androidx.compose.ui.tooling)
}
