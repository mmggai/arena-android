# Arena for Android

A production-oriented native Android shell for **https://arena.ai/**. It preserves the official site's functionality and authentication while adding Android-native system integration, Material 3 chrome, secure WebView policies, navigation, offline feedback, file selection/camera input, and deep links.

## Website assessment and implementation decision

On 3 August 2026, the public site resolves to `https://arena.ai/` and exposes a JavaScript application with **New Chat**, **Leaderboard**, **Search**, battle-mode chat, file input, and reCAPTCHA. Its public HTML does not advertise a stable, documented client API. Reimplementing the chat protocol or scraping private endpoints would be brittle, could defeat reCAPTCHA/session controls, and would risk account security.

Therefore this project deliberately uses an **enhanced, locked-down WebView**, not an undocumented API client. The website remains the source of truth for models, streaming, Markdown/LaTex/code display, conversations, authentication, account functionality, and any server-side push capabilities. A future official API can be introduced behind a repository layer without changing the Compose host UI.

## What is native

* Android 12+ system splash, edge-to-edge Material 3 / Material You shell and system light/dark mode.
* Persistent cookies/session (`CookieManager`); users are not cleared at app launch.
* In-app back history; trusted `arena.ai` links remain in-app and untrusted links use the device browser.
* Refresh with haptics, load progress, offline state, deep links, adaptive sizing (Compose), system share/clipboard via WebView text selection.
* Secure file chooser for documents/images/PDFs and camera capture; downloads are handled by the website/browser rather than silently accessing storage.
* TLS-only configuration, JavaScript enabled only because the authenticated app requires it, no `addJavascriptInterface`, no file-scheme access, no location permission, and no secrets in the app.

## Build

1. Open `ArenaMobile` in Android Studio Ladybug or newer.
2. Use JDK 17 and Android SDK Platform 35.
3. Allow Gradle to download dependencies, then run the `app` configuration on an Android 8.0+ device/emulator.

Command line: `./gradlew :app:assembleDebug` (generate a Gradle wrapper in Android Studio if your environment does not already provide one).

## Push notifications

No public Arena push-registration API was identified. FCM is intentionally not configured: adding it without a server registration endpoint would create a non-functional notification permission. Add Firebase plus the official Arena device-token endpoint when it is available.

## Architecture

Kotlin, Jetpack Compose, Material 3, MVVM (`ArenaViewModel`), Flow (`NetworkMonitor`), Hilt, and a separated `web` integration layer. The narrow WebView boundary makes replacement with official REST/WebSocket repositories straightforward.

## Release checklist

Set the final application id and signing config; provide real adaptive icon assets; verify login, uploads, reCAPTCHA, and deep-link domain verification against the production site; conduct a WebView security review and accessibility/device-matrix test. Do not enable WebView debugging in release builds.
